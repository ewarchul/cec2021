#ifndef CEC2013_INTERFACE_H_
#define CEC2013_INTERFACE_H_

#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "cec2013_functions.h"
#include "globals.h"



void cec2013_func(double *, double *, int, int, int);

#endif // CEC2013_INTERFACE_H_

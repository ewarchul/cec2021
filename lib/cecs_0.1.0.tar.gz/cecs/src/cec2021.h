#ifndef CEC2021_H_
#define CEC2021_H_

#include <R.h>
#include <stdio.h>
#include <stdlib.h>

#include "cec2021_interface.h"

void cec2021(char **, int *, double *, int *, int *, double *, char **);

#endif // CEC2021_H_

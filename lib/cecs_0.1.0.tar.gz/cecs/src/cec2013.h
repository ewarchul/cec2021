#ifndef CEC2013_H_
#define CEC2013_H_

#include <R.h>
#include <stdio.h>
#include <stdlib.h>

#include "cec2013_interface.h"

void cec2013(char **, int *, double *, int *, int *, double *);

#endif // CEC2013_H_

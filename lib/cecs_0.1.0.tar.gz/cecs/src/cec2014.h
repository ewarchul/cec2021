#ifndef CEC2014_H_
#define CEC2014_H_

#include <R.h>
#include <stdio.h>
#include <stdlib.h>

#include "cec2014_interface.h"

void cec2014(char **, int *, double *, int *, int *, double *);
#endif // CEC2014_H_

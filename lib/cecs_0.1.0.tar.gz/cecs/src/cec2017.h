#ifndef CEC2017_H_
#define CEC2017_H_

#include <R.h>
#include <malloc.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

#include "cec2017_interface.h"

void cec2017(char **, int *, double *, int *, int *, double *);

#endif // CEC2017_H_

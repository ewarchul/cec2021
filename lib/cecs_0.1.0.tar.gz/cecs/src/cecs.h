#ifndef CECS_H_
#define CECS_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <R.h>

#include "cec2013.h"
#include "cec2014.h"
#include "cec2017.h"
#include "cec2021.h"
#include "globals.h"



void cecs(char **, char **, int *, double *, int *, int *, double *f, char **);

#endif // CECS_H_

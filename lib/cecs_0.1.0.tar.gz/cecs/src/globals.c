#include "globals.h"

double *OShift, *M, *y, *z, *x_bound;
int ini_flag = 0;
int n_flag, func_flag, *SS;
char *extdata;

#ifndef GLOBALS_H_
#define GLOBALS_H_

extern double *OShift, *M, *y, *z, *x_bound;
extern int ini_flag, n_flag, func_flag, *SS;
extern char *extdata;

#endif // GLOBALS_H_

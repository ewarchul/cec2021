library(testthat)
library(cecs)

test_check("cecs")
